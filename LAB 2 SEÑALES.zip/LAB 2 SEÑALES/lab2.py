import matplotlib.pyplot as plt
import numpy as np 
from numpy import var
import librosa
import sounddevice as sd
from sklearn.decomposition import FastICA

# Archivos de voces y ruidos ya cargados
audio_voces = ["voz_mama.wav", "voz_mari.wav"]
audio_ruido = ["Ruidomama.wav", "ruidomari.wav"]

# Función para cargar un archivo de audio
def loadAudio(archivo):
    data, samplerate = librosa.load(archivo, sr=None)  # Carga el archivo de audio sin cambio de tasa de muestreo
    return data, samplerate

# Función para reproducir un audio
def playAudio(data, sr):
    sd.play(data, sr)  # Reproduce el audio
    sd.wait()  # Espera a que termine la reproducción

# Función para graficar la forma de onda del audio
def graficarSonido(data, sr, title=""):
    t = np.arange(len(data)) / sr  # Calcula el tiempo en segundos
    plt.figure(figsize=(12, 6))  # Tamaño de la figura
    plt.plot(t, data, color='royalblue', lw=1.5)  # Grafica la forma de onda en color azul
    plt.xlim(0, 2)  # Limita el eje x a los primeros 2 segundos
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Amplitud')
    plt.title(title)
    plt.grid(True, linestyle='--', alpha=0.7)  # Añade una cuadrícula punteada
    plt.show()

# Función para analizar el espectro de frecuencias del audio
def analisisEspectral(data, sr, title="Espectro de frecuencias del audio"):
    n = len(data)  # Número de muestras
    T = 1 / sr  # Intervalo de muestreo
    yf = np.fft.fft(data)  # Transformada de Fourier del audio
    xf = np.fft.fftfreq(n, T)[:n // 2]  # Frecuencias correspondientes a la FFT
    
    plt.figure(figsize=(12, 6))  # Tamaño de la figura
    plt.plot(xf, 2.0 / n * np.abs(yf[:n // 2]), color='darkorange', lw=1.5)  # Grafica el espectro en color naranja
    plt.xlim(0, 2000)  # Limita el eje x a 2000 Hz
    plt.xlabel('Frecuencia (Hz)')
    plt.ylabel('Amplitud')
    plt.title(title)
    plt.grid(True, linestyle='--', alpha=0.7)  # Añade una cuadrícula punteada
    plt.show()

# Función para mezclar dos archivos de audio
def mezclarVoces(audio1, audio2):
    signals = []
    data1, sr = loadAudio(audio1)  # Carga el primer archivo
    data2, sr = loadAudio(audio2)  # Carga el segundo archivo
    
    # Ajusta la longitud para que ambas señales tengan el mismo tamaño
    min_len = min(len(data1), len(data2))
    data1 = data1[:min_len]
    data2 = data2[:min_len]
    
    signals.append(data1)
    signals.append(data2)
    
    # Apila las señales para mezclarlas
    mixed_signals = np.vstack(signals)
    return mixed_signals.T, sr  # Transpone la matriz para tener las señales en columnas

# Función para aplicar ICA y separar las señales
def aplicar_ica(signal):
    ica = FastICA(n_components=2, max_iter=1000, tol=0.001)  # Configuración del ICA
    señales_separadas = ica.fit_transform(signal)  # Aplica ICA para separar las señales
    
    return señales_separadas

# Función para calcular la potencia de la señal
def potenciaDeSeñal(voz, ruido):
    potencia_voz = np.mean(voz**2)  # Calcula la potencia de la voz
    potencia_ruido = np.mean(ruido**2)  # Calcula la potencia del ruido
    return potencia_voz, potencia_ruido

# Función para identificar la componente de voz tras aplicar ICA
def identificar_voz(components, sr):
    # Asumimos que la componente más cercana a la forma de onda de la voz original es la voz
    for i, component in enumerate(components.T):
        graficarSonido(component, sr, f"Componente {i+1} para identificación de voz")
        analisisEspectral(component, sr, f"Espectro de la componente {i+1}")
    
    seleccion = int(input("\nSeleccione el número de la componente que parece ser la voz (1 o 2): ")) - 1
    if seleccion < 0 or seleccion >= len(components.T):
        print("Opción no válida.")
        return None
    return components[:, seleccion]  # Devuelve la componente seleccionada

# Menú interactivo para seleccionar opciones
def mostrar_menu():
    print("\nMenú de Opciones:")
    print("1. Cargar y reproducir un archivo de audio")
    print("2. Graficar y analizar espectralmente un archivo de audio")
    print("3. Mezclar voz y ruido")
    print("4. Aplicar ICA para separar señales")
    print("5. Calcular SNR (Relación Señal-Ruido)")
    print("6. Salir")

# Función para seleccionar un archivo de audio de una lista
def seleccionar_audio(lista_audios, tipo):
    print(f"\nSeleccione un {tipo}:")
    for i, archivo in enumerate(lista_audios):
        print(f"{i+1}. {archivo}")
    
    seleccion = int(input("Seleccione una opción (1-3): ")) - 1
    if seleccion < 0 or seleccion >= len(lista_audios):
        print("Opción no válida.")
        return None
    return lista_audios[seleccion]  # Devuelve el archivo seleccionado

# Función para cargar y reproducir un archivo de audio
def opcion_cargar_reproducir():
    archivo = seleccionar_audio(audio_voces, "archivo de voz")
    if archivo:
        data, sr = loadAudio(archivo)
        playAudio(data, sr)

# Función para graficar y analizar un archivo de audio
def opcion_graficar_analizar():
    archivo = seleccionar_audio(audio_voces, "archivo de voz")
    if archivo:
        data, sr = loadAudio(archivo)
        graficarSonido(data, sr, title=f"Forma de onda de {archivo}")
        analisisEspectral(data, sr, title=f"Espectro de {archivo}")

# Función para mezclar un archivo de voz y un archivo de ruido
def opcion_mezclar():
    voz = seleccionar_audio(audio_voces, "voz")
    ruido = seleccionar_audio(audio_ruido, "ruido")
    
    if voz and ruido:
        data_mezclada, sr_mezclada = mezclarVoces(voz, ruido)
        graficarSonido(data_mezclada[:, 0], sr_mezclada, "Señal mezclada - Voz y Ruido")
        analisisEspectral(data_mezclada[:, 0], sr_mezclada, "Espectro - Señal mezclada")
        playAudio(data_mezclada[:, 0], sr_mezclada)

# Función para aplicar ICA y separar la voz
def opcion_aplicar_ica():
    voz = seleccionar_audio(audio_voces, "voz")
    ruido = seleccionar_audio(audio_ruido, "ruido")
    
    if voz and ruido:
        data_mezclada, sr_mezclada = mezclarVoces(voz, ruido)
        señales_separadas = aplicar_ica(data_mezclada)
        
        # Identificar y reproducir solo la componente que parece ser la voz
        voz_separada = identificar_voz(señales_separadas, sr_mezclada)
        if voz_separada is not None:
            graficarSonido(voz_separada, sr_mezclada, "Voz Separada")
            analisisEspectral(voz_separada, sr_mezclada, "Espectro de la voz separada")
            print("Reproduciendo voz separada...")
            playAudio(voz_separada, sr_mezclada)
            
            # Cargar el ruido original para el cálculo del SNR
            ruido_original, sr_ruido = loadAudio(ruido)  # Cargar los datos de ruido
            
            # Ajustar el tamaño del ruido a la longitud de la voz separada
            min_len = min(len(voz_separada), len(ruido_original))
            voz_separada = voz_separada[:min_len]
            ruido_original = ruido_original[:min_len]
            
            # Calcular la potencia de la voz separada y el ruido
            potencia_voz_separada = np.var(voz_separada)  # Varianza como estimación de potencia
            potencia_ruido = np.mean(ruido_original**2)  # Potencia del ruido
            
            # Calcular el SNR
            snr = 10.0 * np.log10(potencia_voz_separada / potencia_ruido)
            print(f"SNR para la voz separada: {snr:.2f} dB")

# Función para calcular la relación señal-ruido (SNR) para cada archivo
def opcion_calcular_snr():
    for i in range(3):
        voz, sr = loadAudio(audio_voces[i])
        ruido, sr = loadAudio(audio_ruido[i])
        potencia_voz, potencia_ruido = potenciaDeSeñal(voz, ruido)
        snr = 10.0 * np.log10(potencia_voz / potencia_ruido)  # Calcula el SNR en decibelios
        print(f"SNR para {audio_voces[i]}: {snr:.2f} dB")

# Bucle principal del menú
def main():
    while True:
        mostrar_menu()  # Muestra el menú de opciones
        opcion = input("\nSeleccione una opción (1-6): ")
        
        # Ejecuta la opción seleccionada
        if opcion == "1":
            opcion_cargar_reproducir()
        elif opcion == "2":
            opcion_graficar_analizar()
        elif opcion == "3":
            opcion_mezclar()
        elif opcion == "4":
            opcion_aplicar_ica()
        elif opcion == "5":
            opcion_calcular_snr()
        elif opcion == "6":
            print("Saliendo...")
            break  # Sale del bucle y termina el programa
        else:
            print("Opción no válida, intente de nuevo.")

if __name__ == "__main__":
    main()  # Ejecuta la función principal

